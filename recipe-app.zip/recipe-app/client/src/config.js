const URL = `http://localhost:3040`;
const APP_ID = '58df0d7c';
const APP_KEY = '2ae0155ae5f4dfc01fc4641b93c0602f';

export { URL, APP_ID, APP_KEY };


